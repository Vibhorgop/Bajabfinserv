package bajajfinserv;

import java.io.FileReader;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class main {


    public static void main(String[] args) {
        // Validate input parameters
        if (args.length != 2) {
            System.err.println("Usage: java -jar test.jar <PRN Number> <path to JSON file>");
            return;
        }

        String prnNumber = args[0].toLowerCase().replaceAll("\\s+", ""); // PRN number in all lowercase without spaces
        String jsonFilePath = args[1];

        try {
            // Read JSON file and find the first occurrence of the key "destination"
            String destinationValue = findFirstDestinationValue(jsonFilePath);
            if (destinationValue == null) {
                System.err.println("Key 'destination' not found in the JSON file.");
                return;
            }

            // Generate a random 8-character alphanumeric string
            String randomString = generateRandomString(8);

            // Concatenate PRN number, destination value, and random string
            String concatenatedValue = prnNumber + destinationValue + randomString;

            // Compute MD5 hash of the concatenated value
            String md5Hash = computeMD5Hash(concatenatedValue);

            // Output the result in the specified format
            System.out.println(md5Hash + ";" + randomString);
        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }

    private static String findFirstDestinationValue(String jsonFilePath) throws IOException, ParseException {
        JSONParser parser = new JSONParser();
        FileReader reader = new FileReader(jsonFilePath);
        JSONObject jsonObject = (JSONObject) parser.parse(reader);
        return traverseJSON(jsonObject);
    }

    private static String traverseJSON(JSONObject jsonObject) {
        for (Object key : jsonObject.keySet()) {
            if (key.equals("destination")) {
                return jsonObject.get(key).toString();
            }
            Object value = jsonObject.get(key);
            if (value instanceof JSONObject) {
                String result = traverseJSON((JSONObject) value);
                if (result != null) {
                    return result;
                }
            }
        }
        return null; // Key not found
    }

    private static String generateRandomString(int length) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < length; i++) {
            result.append(characters.charAt(random.nextInt(characters.length())));
        }
        return result.toString();
    }

    private static String computeMD5Hash(String input) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] hashInBytes = md.digest(input.getBytes());
        StringBuilder sb = new StringBuilder();
        for (byte b : hashInBytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
